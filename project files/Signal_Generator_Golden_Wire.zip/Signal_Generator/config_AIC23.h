/*********************************/
/* config_AIC23.h                */
/* Interface zu config_AIC23.c   */
/*   F. Quint, 2008              */
/*********************************/

void Config_DSK6713_AIC23(void);
static void set_aic23_register(MCBSP_Handle,unsigned short, unsigned short);
