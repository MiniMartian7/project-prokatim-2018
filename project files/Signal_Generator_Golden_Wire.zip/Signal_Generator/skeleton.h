#ifndef TEMPLATE_H_
#define TEMPLATE_H_

void process_ping_SWI(void);
void process_pong_SWI(void);
void EDMA_interrupt_service(void);
void config_EDMA(void);
void config_interrupts(void);
void SWI_LEDtoggle_ISR(void);
void tsk_led_toggle(void);
void periodicFctn_500ms(void);
	
#endif /*TEMPLATE_H*/
