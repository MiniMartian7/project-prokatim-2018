/***********************************************************
*  skeleton.c
*  Example for ping-pong processing
*  Caution: It is intended, that this file ist not runnable. 
*  The file contains mistakes and omissions, which shall be
*  corrected and completed by the students.
*
*   F. Quint, HsKA
************************************************************/

#include <Signal_Generatorcfg.h>
#include <std.h>
#include <csl.h>
#include <csl_mcbsp.h>
#include <csl_irq.h>
#include <csl_edma.h>
#include <swi.h>
#include <dsk6713_led.h>
#include <math.h>
#include <stdbool.h>
#include "config_AIC23.h"
#include "skeleton.h"
//#include "LUT.h"	//NO longer needed
#include <limits.h>	//Defines limits for all types of variables

//all defines
#define BUFFER_LEN 960 //512
#define F_S 48000			//Samplefrequenz
#define F_MIN 100			//Minimalfrequenz
#define F_MAX 100000		//Maximalfrequenz
#define N_ANZ_LUT 240			//Azahl ben�tigter Werte f_s / f_min
#define N_LUT_EFF 480
#define LANCZOS_A 2
#define PI 3.141592654
#define HARMONICS 6

/*
 * switch between IIR and DDS
 * this value should be changeable by GEL file
 */
volatile bool IIR = 0;

volatile double frequency[6] = {661.0,1331.0,2000.0,2689.0,3378.0,4076.0};
//volatile double frequency[6] = {150.0,1000.0,300.0,400.0,50.0,650.0};

volatile double amplitude[6] = {1.0,0.38,0.06,0.1,0.05,0.02};
//volatile double amplitude[6] = {0.74,0.5,0.4,0.3,0.2,0.1};

volatile double phase[6] = {0,0,0,0,0,0};

volatile Uint32 time = 0;

/*
 * Handle for the Mcbsp1
 */
MCBSP_Handle hMcbsp1=0;

/*
 * Array for the accumulation of all wave values => this is what i copy to the double buffered output 2 times in a row
 */
short Values_Out[N_LUT_EFF];

/*
 * Transfer-Complete-Codes for EDMA-Jobs
 */
int tccXmtPing;
int tccXmtPong;

/*
 * Timer Handle
 */
TIMER_Handle hTimer1 = 0;

/*
 * EDMA-Handles
 */
EDMA_Handle hEdmaXmt;
EDMA_Handle hEdmaXmtReloadPing;
EDMA_Handle hEdmaXmtReloadPong;


/* All internal Memorys
 * Lookup Table Values N=240
 * Sign and index (position) of the phase of all harmonics in the DDS
 * Ping and Pong for Double Buffering
*/
#pragma DATA_SECTION(LUT_Values, ".LUTbuffers");
short LUT_Values[N_ANZ_LUT];
#pragma DATA_SECTION(DDS_Sign, ".databuffers");
volatile short DDS_Sign[HARMONICS] = {1,1,1,1,1,1};
#pragma DATA_SECTION(DDS_Index, ".databuffers");
volatile double DDS_Index[HARMONICS] = {0,0,0,0,0,0};
#pragma DATA_SECTION(Buffer_out_ping, ".databuffers");
short Buffer_out_ping[BUFFER_LEN];
#pragma DATA_SECTION(Buffer_out_pong, ".databuffers");
short Buffer_out_pong[BUFFER_LEN];

//Configuration for timer1
TIMER_Config configTIMER1 = {
		 0x00000201, //CTL Timer Control Register
		 /*
		  *
		  *  XXXXXXXXXXXXXXXXXXXX
		  *  0	TSTAT
		  *  0	INVINP   Noninverted TINP drives timer.
		  *  1	CLKSRC  Internal clock source CPU clock/4
		  *  0	CP	Pulse mode. TSTAT is active one CPU clock after the timer reaches the timer period
		  *  0	HLD Counter is disabled and held in the current state !!PLAY/PAUSE!!
		  *  0	GO  Resets Timer if 1 and starts to count when HLD 1
		  *  X 	Reserved
		  *  0	PWID  Pulse width bit
		  *  0	DATIN
		  *  0	DATOUT
		  *  0	INVOUT Noninverted TSTAT drives TOUT
		  *  1	FUNC TOUT=Timer Output Pin
		  */

		 0xFFFFFFFF, //PRD Timer Period Register
		 0x00000000  //CNT Timer Count Register
};


//Configuration for McBSP1 (data-interface)
MCBSP_Config datainterface_config = {
		/* McBSP Control Register */
        MCBSP_FMKS(SPCR, FREE, NO)              |	//  Freilauf
        MCBSP_FMKS(SPCR, SOFT, YES)          	|	// ***S.76 Serial Port Soft Mode (1) damit w�hrend er Emulation der Port erst nach der �bertragung abschaltet. XXXXXXXXXXXXXXXXXXXXXXX
        MCBSP_FMKS(SPCR, FRST, YES)             |	// Framesync ist ein
        MCBSP_FMKS(SPCR, GRST, YES)             |	// Reset aus, damit l�uft der Samplerate- Generator
        MCBSP_FMKS(SPCR, XINTM, XRDY)           |	// ***aus der include Datei csl_mcbsphal.h nach Markus XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxx
        MCBSP_FMKS(SPCR, XSYNCERR, NO)          |	// empf�ngerseitig keine �berwachung der Synchronisation
        MCBSP_FMKS(SPCR, XRST, YES)             |	// Sender l�uft (kein Reset- Status)	
        MCBSP_FMKS(SPCR, DLB, OFF)              	|	// ***Loopback (Kurschluss) nicht aktiv  XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        MCBSP_FMKS(SPCR, RJUST, RZF)            |	// rechtsb�ndige Ausrichtung der Daten im Puffer
        MCBSP_FMKS(SPCR, CLKSTP, DISABLE)       |	// Clock startet ohne Verz�gerung auf fallenden Flanke (siehe auch PCR-Register)
        MCBSP_FMKS(SPCR, DXENA, OFF)            |	// DX- Enabler wird nicht verwendet
        MCBSP_FMKS(SPCR, RINTM, RRDY)           |	// Sender Interrupt wird durch "RRDY-Bit" ausgel�st
        MCBSP_FMKS(SPCR, RSYNCERR, NO)          |	// senderseitig keine �berwachung der Synchronisation
        MCBSP_FMKS(SPCR, RRST, YES),			// Empf�nger l�uft (kein Reset- Status)
		/* Empfangs-Control Register */
        MCBSP_FMKS(RCR, RPHASE, SINGLE)         |	// Nur eine Phase pro Frame
        MCBSP_FMKS(RCR, RFRLEN2, DEFAULT)       |	// L�nge in Phase 2, unrelevant
        MCBSP_FMKS(RCR, RWDLEN2, DEFAULT)       |	// Wortl�nge in Phase 2, unrelevant
        MCBSP_FMKS(RCR, RCOMPAND, MSB)          |	// kein Compandierung der Daten (MSB first)
        MCBSP_FMKS(RCR, RFIG, NO)               |	// Rahmensynchronisationspulse (nach dem ersten Puls)) startet die �bertragung neu
        MCBSP_FMKS(RCR, RDATDLY, 0BIT)          |	// keine Verz�gerung (delay) der Daten
        MCBSP_FMKS(RCR, RFRLEN1, OF(1))         |	// L�nge der Phase 1 --> 1 Wort
        MCBSP_FMKS(RCR, RWDLEN1, 16BIT)         |	// ***SOLLTE 16 sein XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        MCBSP_FMKS(RCR, RWDREVRS, DISABLE),		// 32-bit Reversal nicht genutzt
		/* Sende-Control Register */
        MCBSP_FMKS(XCR, XPHASE, SINGLE)         |	// ***Single Frame f�r die �bertragung  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        MCBSP_FMKS(XCR, XFRLEN2, DEFAULT)       |	// L�nge in Phase 2, unrelevant
        MCBSP_FMKS(XCR, XWDLEN2, DEFAULT)       |	// Wortl�nge in Phase 2, unrelevant
        MCBSP_FMKS(XCR, XCOMPAND, MSB)          |	// kein Compandierung der Daten (MSB first)
        MCBSP_FMKS(XCR, XFIG, NO)               |	// Rahmensynchronisationspulse (nach dem ersten Puls)) startet die �bertragung neu
        MCBSP_FMKS(XCR, XDATDLY, 0BIT)          |	// keine Verz�gerung (delay) der Daten
        MCBSP_FMKS(XCR, XFRLEN1, OF(1))         |	// L�nge der Phase 1 --> 1 Wort
        MCBSP_FMKS(XCR, XWDLEN1, 16BIT)         |	// Wortl�nge in Phase 1 --> 16 bit
        MCBSP_FMKS(XCR, XWDREVRS, DISABLE),		// 32-bit Reversal nicht genutzt
		/* Sample Rate Generator Register */
        MCBSP_FMKS(SRGR, GSYNC, FREE)        |	// Einstellungen nicht relevant da
        MCBSP_FMKS(SRGR, CLKSP, RISING)        |	// der McBSP1 als Slave l�uft
        MCBSP_FMKS(SRGR, CLKSM, CLKS)        |	// und den Takt von aussen
        MCBSP_FMKS(SRGR, FSGM, DEFAULT)         |	// ***vorgegeben bekommt.      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        MCBSP_FMKS(SRGR, FPER, OF(0))         |	// --
        MCBSP_FMKS(SRGR, FWID, OF(0))         |	// --
        MCBSP_FMKS(SRGR, CLKGDV, OF(1)),		// --
		/* Mehrkanal */
        MCBSP_MCR_DEFAULT,				// Mehrkanal wird nicht verwendet
        MCBSP_RCER_DEFAULT,				// dito
        MCBSP_XCER_DEFAULT,				// dito
		/* Pinout Control Register */
        MCBSP_FMKS(PCR, XIOEN, SP)              |	// Pin wird f�r serielle Schnittstelle verwendet (alternativ GPIO)
        MCBSP_FMKS(PCR, RIOEN, SP)              |	// Pin wird f�r serielle Schnittstelle verwendet (alternativ GPIO)
        MCBSP_FMKS(PCR, FSXM, EXTERNAL)         |	// Framesync- Signal f�r Sender kommt von extern (Slave)
        MCBSP_FMKS(PCR, FSRM, EXTERNAL)         |	// Framesync- Signal f�r Empf�nger kommt von extern (Slave)
        MCBSP_FMKS(PCR, CLKXM, INPUT)           |	// Takt f�r Sender kommt von extern (Slave)
        MCBSP_FMKS(PCR, CLKRM, INPUT)           |	// Takt f�r Empf�nger kommt von extern (Slave)
        MCBSP_FMKS(PCR, CLKSSTAT, DEFAULT)      |	// unrelevant da PINS keine GPIOs
        MCBSP_FMKS(PCR, DXSTAT, DEFAULT)        |	// unrelevant da PINS keine GPIOs
        MCBSP_FMKS(PCR, FSXP, ACTIVEHIGH)       |	// Framesync senderseitig ist "activehigh"
        MCBSP_FMKS(PCR, FSRP, ACTIVEHIGH)       |	// Framesync empf�ngerseitig ist "activehigh"
        MCBSP_FMKS(PCR, CLKXP, FALLING)         |	// Datum wird bei fallender Flanke gesendet
        MCBSP_FMKS(PCR, CLKRP, RISING)			// Datum wird bei steigender Flanke �bernommen
};

/*
 * template for a EDMA configuration
 */
EDMA_Config configEDMA;
EDMA_Config configEDMAStd = {
    EDMA_FMKS(OPT, PRI, DEFAULT)          |  // auf beide Queues verteilen (war LOW)
    EDMA_FMKS(OPT, ESIZE, 16BIT)       |  //*** Element size
    EDMA_FMKS(OPT, 2DS, NO)            |  // kein 2D-Transfer
    EDMA_FMKS(OPT, SUM, DEFAULT)          |  // Quell-update mode
    EDMA_FMKS(OPT, 2DD, NO)            |  // 2kein 2D-Transfer
    EDMA_FMKS(OPT, DUM, DEFAULT)           |  //*** Ziel-update mode
    EDMA_FMKS(OPT, TCINT,YES)  	       |  //*** EDMA interrupt erzeugen?
    EDMA_FMKS(OPT, TCC, OF(0))         |  // Transfer complete code (TCC)
    EDMA_FMKS(OPT, LINK, YES)          |  // Link Parameter nutzen?
    EDMA_FMKS(OPT, FS, NO),               // Frame Sync nutzen?

	//Word 1 - Source address (SRC)
    EDMA_FMKS(SRC, SRC, OF(0)),           // Quell-Adresse

	//Word 2 - Count (CNT)
    EDMA_FMK (CNT, FRMCNT, 0)       |  // Anzahl Frames NULL IST EINS
    EDMA_FMK (CNT, ELECNT, BUFFER_LEN),   // Anzahl Elemente HIER IST NULL AUCH 0 (NUMVALUES in Vorlesung)

	//Word 3 - Destination Address (DST)
	EDMA_FMKS(DST, DST, OF(0)),       		  // Ziel-Adresse auf 0 setzen

	//Word 4 - Indices (IDC)
    EDMA_FMKS(IDX, FRMIDX, DEFAULT)    |  // Frame index Wert
    EDMA_FMKS(IDX, ELEIDX, DEFAULT),      // Element index Wert

	//Word 5 - Reload (RLD)
    EDMA_FMK (RLD, ELERLD, 0)       |  // Reload Element
    EDMA_FMKS (RLD, LINK, DEFAULT)            // Reload Link
};





main()
{
	CSL_init();  //initiate the chip support library

	Config_DSK6713_AIC23();//Configure McBSP0 and AIC23
	
	LUT_calc();	//creates the look up table

	/* switch on and off LEDs */
	DSK6713_LED_on(0);
	DSK6713_LED_off(1);
	DSK6713_LED_on(2);
	DSK6713_LED_off(3);

	/* configure the timer */
	hTimer1 = TIMER_open(TIMER_DEV1,TIMER_OPEN_RESET);
	TIMER_config(hTimer1, &configTIMER1);

	/* Configure McBSP1*/
	hMcbsp1 = MCBSP_open(MCBSP_DEV1, MCBSP_OPEN_RESET);
    MCBSP_config(hMcbsp1, &datainterface_config);
    
	/* configure EDMA */
    config_EDMA();

    /* finally the interrupts */
    config_interrupts();

    MCBSP_start(hMcbsp1, MCBSP_XMIT_START | MCBSP_RCV_START , 0x00003000); //start the Mcbsp1

} /* finished*/


/*
 * configures the EDMA
 */
void config_EDMA(void)
{
	//===================================================================
	// Transmit Part
	//===================================================================

	// Configuration for writing
	hEdmaXmt = EDMA_open(EDMA_CHA_XEVT1, EDMA_OPEN_RESET);  //EDMA Channel for XEVT1
	hEdmaXmtReloadPing = EDMA_allocTable(-1);               //Reload-Parameters
	hEdmaXmtReloadPong = EDMA_allocTable(-1);

	//-------------------------------------------------------------------
	// Start EDMA configuration and Ping Reload configuration
	//-------------------------------------------------------------------
	tccXmtPing = EDMA_intAlloc(-1);                        // next available TCC TRANSFER COMPLETE
	configEDMA = configEDMAStd;
	configEDMA.opt |=
			EDMA_FMKS(OPT, PRI, LOW)          |  // Priority
		    EDMA_FMKS(OPT, SUM, INC)          |  // Source update mode (yes increment => double buffer mode)
		    EDMA_FMKS(OPT, DUM, NONE)           |  // Destiation update mode (no it's ever the same address)
			EDMA_FMK(OPT, TCC, tccXmtPing);		  // Transfer complete code (TCC)
	configEDMA.src = (Uint32)Buffer_out_ping;  //  Source addr
	configEDMA.dst = MCBSP_getXmtAddr(hMcbsp1);	//Destination address

	EDMA_config(hEdmaXmt, &configEDMA);//transfer configured parameters to the reload parameter set
	EDMA_config(hEdmaXmtReloadPing, &configEDMA);//transfer configured parameters to the reload parameter set

	//-------------------------------------------------------------------
	// Pong Reload configuration
	//-------------------------------------------------------------------
	tccXmtPong = EDMA_intAlloc(-1);                        // next available TCC TRANSFER COMPLETE
	configEDMA = configEDMAStd;
	configEDMA.opt |=
			EDMA_FMKS(OPT, PRI, HIGH)          |  // Priority
		    EDMA_FMKS(OPT, SUM, INC)          |  // Source update mode (yes increment => double buffer mode)
		    EDMA_FMKS(OPT, DUM, NONE)           |  // Destiation update mode (no it's ever the same address)
			EDMA_FMK(OPT, TCC, tccXmtPong);		  // Transfer complete code (TCC)
	configEDMA.src = (Uint32)Buffer_out_pong;  //  Source addr
	configEDMA.dst = MCBSP_getXmtAddr(hMcbsp1);	//Destination address

	EDMA_config(hEdmaXmtReloadPong, &configEDMA);		//transfer configured parameters to the reload parameter set

	// link transfers ping -> pong -> ping Transmit
	EDMA_link(hEdmaXmt,hEdmaXmtReloadPong);
	EDMA_link(hEdmaXmtReloadPong,hEdmaXmtReloadPing);
	EDMA_link(hEdmaXmtReloadPing,hEdmaXmtReloadPong);

	// first clear then enable the EDMA TCC flags
	EDMA_intClear(tccXmtPing);
	EDMA_intClear(tccXmtPong);
	EDMA_intEnable(tccXmtPing);
	EDMA_intEnable(tccXmtPong);

	// Enable and start the transmit EDMA
	EDMA_enableChannel(hEdmaXmt);
}


/*
 * config_interrupts()
 *
 * configure and enable all needed interrupts
 */
void config_interrupts(void)
{
	IRQ_map(IRQ_EVT_EDMAINT, 8);	//map the EDMA interrupt to the hardware interrupt no. 8

	IRQ_clear(IRQ_EVT_EDMAINT);		//clear interrupt flag of the EDMA

	IRQ_enable(IRQ_EVT_EDMAINT);	//Enable the EDMA Interrupt

	IRQ_globalEnable();				//Enable all Interrupts
	SWI_enable();					//enable all software interrupts
}


/*
 * EDMA_ISR()
 *
 * Hardware interrupt service routine for EDMA interrupt
 * it checks which tcc was triggered and post the software interrupt
 */
void EDMA_ISR(void)
{
	if(EDMA_intTest(tccXmtPing)) {
		EDMA_intClear(tccXmtPing);
		SWI_post(&Ping_SWI);
	}
	else {
		EDMA_intClear(tccXmtPong);
		SWI_post(&Pong_SWI);
	}
}

/*
 * process_ping_SWI()
 *
 * ping buffer calls the DDS or IIR (depends on switch)
 * writes the sum of the waves (Values_Out) to the output buffer
 * it writes each value twice because of the left/right channel splitting of the AIC23 Codec
 * that means, that each value in an odd index will written to the left channel and each value in an even index will written to the right headphone
 */
void process_ping_SWI(void)		// THIS IS THE GOLDEN WIRE, IT COPIES! HERE COMES THE COMPLEX ALGORITHM
{
	TIMER_start(hTimer1);


	int i = 0,j = 0;

	for(i=0;i<HARMONICS;i++)
		DDS(i);

	for(i=0; i<N_LUT_EFF; i++)
	{
		Buffer_out_ping[j] = Values_Out[i];			//Zwei Eintr�ge damit zweimal hintereinander der gleiche Wert geschrieben wird
		Buffer_out_ping[j+1] = Values_Out[i];
		j += 2;
		Values_Out[i] = 0;
	}

	TIMER_pause(hTimer1);
	time = TIMER_getCount(hTimer1);
}

/*
 * process_pong_SWI()
 *
 * pong buffer calls the DDS or IIR (depends on switch)
 * writes the sum of the waves (Values_Out) to the output buffer
 * it writes each value twice because of the left/right channel splitting of the AIC23 Codec
 * that means, that each value in an odd index will written to the left channel and each value in an even index will written to the right headphone
 */
void process_pong_SWI(void)
{
	int i=0,j = 0;

	for(i=0;i<HARMONICS;i++)
		DDS(i);

	for(i=0; i<N_LUT_EFF; i++)
	{
		Buffer_out_pong[j] = Values_Out[i];
		Buffer_out_pong[j+1] = Values_Out[i];
		j += 2;
		Values_Out[i] = 0;
	}
}


/*
 * Lanczos_Calculation(double)
 *
 * This function does a interpolation by using the Lanczos Kernel
 */
double Lanczos_Calculation(double x)
{
	int floored_x = (int) x;
	int i = 0;

	double sum = 0;

	/*for(i= floored_x - LANCZOS_A + 1 ; i <= floored_x + LANCZOS_A ; i++)
	{
		if(i < 0) //check if our index fall below 0 => get the value from the back of the LUT
			sum += LUT_Values[i+N_ANZ_LUT] * Lanczos_Kernel(x - (i+N_ANZ_LUT));
		else if (i > N_ANZ_LUT - 1) //check if our index rise above the LUT length => get the value from the front of the LUT
			sum += LUT_Values[i-N_ANZ_LUT] * Lanczos_Kernel(x - (i-N_ANZ_LUT));
		else //normal case (index between 0 and LUT length)
			sum += LUT_Values[i] * Lanczos_Kernel(x - i);
	}*/


	if(floored_x < 1){	//check for floor-break. This can only happen if pos is smaller than 1 -> then floorPos will be 0. Therefore, we know the values for "i" here.
		double xx = x+1;
		sum = sum + (LUT_Values[N_ANZ_LUT-1] * ((((-0.5*xx + 2.5)*xx - 4.0)*xx) + 2.0));
		xx=x;
		sum = sum + (LUT_Values[0] * (((1.5*xx-2.5)*xx*xx)+1.0));
		xx=-x+1;
		sum = sum + (LUT_Values[1] * (((1.5*xx-2.5)*xx*xx)+1.0));
		xx=-x+2;
		sum = sum + (LUT_Values[2] * ((((-0.5*xx + 2.5)*xx - 4.0)*xx) + 2.0));

	} else if(floored_x+2 > N_ANZ_LUT-1){	//ceiling-break. This can happen for multiple values of pos, so we still have to use a loop here.
		for (i=floored_x-1;i<floored_x+3;i++){
			if(i>N_ANZ_LUT-1){
				sum = sum + (LUT_Values[i-N_ANZ_LUT] * Lanczos_Kernel(x-i));
			} else{
				sum = sum + (LUT_Values[i] * Lanczos_Kernel(x-i));
			}
		}
	} else{	//this is the regular case which gets executed almost every time. The Lanczos Funtion has been replaced with the approximation functions themselves -> otherwise, the calculation is too slow!
		double xx = x - floored_x + 1;
		sum = sum + (LUT_Values[floored_x-1] * ((((-0.5*xx + 2.5)*xx - 4.0)*xx) + 2.0));
		xx = x - floored_x;
		sum = sum + (LUT_Values[floored_x] * (((1.5*xx-2.5)*xx*xx)+1.0));
		xx = -x + floored_x + 1;
		sum = sum + (LUT_Values[floored_x+1] * (((1.5*xx-2.5)*xx*xx)+1.0));
		xx = -x + floored_x + 2;
		sum = sum + (LUT_Values[floored_x+2] * ((((-0.5*xx + 2.5)*xx - 4.0)*xx) + 2.0));
	}

	return sum;
}




/*
 * This Function creates the output values by using a DDS
 */
void DDS(short WaveIndex)//short WaveIndex, double frequency, double amplitude, double phase)
{
	double index = DDS_Index[WaveIndex];	//Loading last Index from the actual wave
	short sign = DDS_Sign[WaveIndex];		//Loading last Sign from the actual wave

	double step = frequency[WaveIndex] / F_MIN;	//step width through the LUT (phase)

	short newindex = 0;

	// this loop makes the wave of one frequency and ads it to the sum of all 6 harmonics (see ping/pong buffer)
	int i = 0;
	for(i = 0 ; i <  N_LUT_EFF ; i ++)
	{
		newindex = 0;
		//if we reach the end of the lookup table, we have to change the sign and correct the index value
		if(index > N_ANZ_LUT-1)
		{
			sign = -sign;
			index -= N_ANZ_LUT;
		}


		if(WaveIndex == 0)
		{
			newindex = floor(index);
			if(index - newindex != 0)
				Values_Out[i] = sign * amplitude[WaveIndex] * Lanczos_Calculation(index);
			else
				Values_Out[i] = sign * amplitude[WaveIndex] * LUT_Values[newindex];
		}
		else
		{
			if(index - newindex != 0)
				Values_Out[i] += sign * amplitude[WaveIndex] * Lanczos_Calculation(index);
			else
				Values_Out[i] += sign * amplitude[WaveIndex] * LUT_Values[newindex];
		}



		// build the sum ob all harmonic waves by adding each wave to the output values array (each time open this DDS function)
		//Values_Out[i] += sign * amplitude[WaveIndex] * LUT_Values[newindex];

		//increment the index step by step
		index += step;
	}

	//save the last index value and the last sign of each wave => for continuous wave
	DDS_Index[WaveIndex] = index;
	DDS_Sign[WaveIndex] = sign;

}


/* 500ms PERIODIC FUNCTION ISR */
void periodicFctn_500ms(void)
{
	SWI_post(&LED_Toggle_SWI); 		// post SWI every 500ms
}


void SWI_LEDToggle(void)		// DIE BEIDEN UNTEN SIND UNTERPROGRAMME
{
	SEM_postBinary(&SEM_LEDToggle);
}

void tsk_led_toggle(void)				// KLEINES TOGGLE PROGRAMM
{
	// initializatoin of the task
	// nothing to do

	// process
	while(1) {
		SEM_pendBinary(&SEM_LEDToggle, SYS_FOREVER);
		DSK6713_LED_toggle(0);
		DSK6713_LED_toggle(1);
		DSK6713_LED_toggle(2);
		DSK6713_LED_toggle(3);
	}
}

/*
 * LUT_calc()
 *
 * Calculation of half a period of a sin wave as Lookup Table
 * scaled to the maximum of Short variable and to the number of harmonics
 * and also drives the DAC to the maximum
 * it saves the values in the internal ram (iram)
 */
void LUT_calc(void)
{
	float harm = (float)HARMONICS;
	int i=0;
	for(i=0 ; i < N_ANZ_LUT; i++) {
			LUT_Values[i] = (SHRT_MAX-1.0)*(1/harm)*sin(PI*(1.0/N_ANZ_LUT)*i);
	}
}


/*
 * Lanczos_Kernel(double)
 *
 * Approximation of the Lanczos function L(x)
 */
double Lanczos_Kernel(double x)
{
	if(x<0) x = -x;		//get the absolute of x
	double lancVal = 0;

	if(x <= 1.0)
		lancVal = 1.5 * pow(abs(x),3.0) - pow(2.5 * x,2.0) + 1.0;
	else if (x > 1.0 && x < 2.0 )
		lancVal = -0.5 * pow(abs(x),3.0) + 2.5 * pow(x,2.0) -4.0 * abs(x) + 2.0;
	else
		return 0;

	return lancVal;
}
