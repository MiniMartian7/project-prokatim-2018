/*
 * main.c
 */

int zyx=1;

int main(void) {
	int abcdefg=0;
	
	return 0;
}
